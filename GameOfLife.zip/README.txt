Instruction for compling and runing the assignment:

1. Please install the latest LTS version of jre, jdk. Version of my java is 14.0.2. 
Note: you can try any older version 8,9,or 10 they should work fine.

2. Move both of the .java files into a same folder.

3. Launch terminal and navigate to the folder where the .java files exist.

4. In the terminal type: javac *.java
5. then type: java Life.java "sizeOfwidth&Height" "maxIteration" "L/P/R". 
For example: java Life.java 100 100 L

6.Repeat Step 5 for different input.

7.Done.
