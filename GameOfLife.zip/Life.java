import java.awt.Color;

public class Life {
    private int[][] current; // current state of cells
    private int[][] previous; // previous state of cells
    private int[][] border;
    private int x;             //width & height of the grid
    private int m;      //max number of iterations
    final int  magnification = 10; // pixel-width of each cell
    Picture pic;
    private String pattern;
    final Color white;
    final Color black;

    public Life(int n, int m, String pattern) {
        this.x = n;
        this.pattern = pattern;
        this.m = m;
        this.current = new int [this.x] [this.x];
        this.previous = new int [this.x] [this.x];
        this.white = new Color(255, 255, 255);
        this.black = new Color(0, 0, 0);
        pic = new Picture(n*magnification, n*magnification);

        //initialize
        for(int col=0; col< n*this.magnification; col++){
            for (int row=0; row< n* this.magnification; row++){
                pic.set(col,row,this.white);
            }
        }

        if(this.pattern.equals("R")){
            for(int col=0; col< n; col++){
                for(int row=0;row<n; row++){
                    this.current[col][row] = (int) ((this.magnification* Math.random()) %2); // randomize true or false for each cells
                }
            }

        }if(this.pattern.equals("L")){
            this.current[this.x/2 -1][this.x/2 -1] = 1;
            this.current[this.x/2 -1][this.x/2 +1] = 1;
            this.current[this.x/2][this.x/2 +2] = 1;
            this.current[this.x/2 + 1][this.x/2 +2] = 1;
            this.current[this.x/2 + 2][this.x/2 +2] = 1;
            this.current[this.x/2 + 3][this.x/2 +2] = 1;
            this.current[this.x/2 + 3][this.x/2 +1] = 1;
            this.current[this.x/2 + 3][this.x/2] = 1;
            this.current[this.x/2 + 2][this.x/2 -1] = 1;
        }else if(this.pattern.equals("P")){
            this.current[this.x/2 +2][this.x/2 -1] =1;
            this.current[this.x/2 +3][this.x/2 -1] =1;
            this.current[this.x/2 +4][this.x/2 -1] =1;
            this.current[this.x/2 -2][this.x/2 -1] =1;
            this.current[this.x/2 -3][this.x/2 -1] =1;
            this.current[this.x/2 -4][this.x/2 -1] =1;
            this.current[this.x/2 +1][this.x/2 -2] =1;
            this.current[this.x/2 +1][this.x/2 -3] =1;
            this.current[this.x/2 +1][this.x/2 -4] =1;
            this.current[this.x/2 -1][this.x/2 -2] =1;
            this.current[this.x/2 -1][this.x/2 -3] =1;
            this.current[this.x/2 -1][this.x/2 -4] =1;
            this.current[this.x/2 +6][this.x/2 -2] =1;
            this.current[this.x/2 +6][this.x/2 -3] =1;
            this.current[this.x/2 +6][this.x/2 -4] =1;
            this.current[this.x/2 -6][this.x/2 -2] =1;
            this.current[this.x/2 -6][this.x/2 -3] =1;
            this.current[this.x/2 -6][this.x/2 -4] =1;
            this.current[this.x/2 +2][this.x/2 -6] =1;
            this.current[this.x/2 +3][this.x/2 -6] =1;
            this.current[this.x/2 +4][this.x/2 -6] =1;
            this.current[this.x/2 -2][this.x/2 -6] =1;
            this.current[this.x/2 -3][this.x/2 -6] =1;
            this.current[this.x/2 -4][this.x/2 -6] =1;

            this.current[this.x/2 +2][this.x/2 +1] =1;
            this.current[this.x/2 +3][this.x/2 +1] =1;
            this.current[this.x/2 +4][this.x/2 +1] =1;
            this.current[this.x/2 -2][this.x/2 +1] =1;
            this.current[this.x/2 -3][this.x/2 +1] =1;
            this.current[this.x/2 -4][this.x/2 +1] =1;
            this.current[this.x/2 +1][this.x/2 +2] =1;
            this.current[this.x/2 +1][this.x/2 +3] =1;
            this.current[this.x/2 +1][this.x/2 +4] =1;
            this.current[this.x/2 -1][this.x/2 +2] =1;
            this.current[this.x/2 -1][this.x/2 +3] =1;
            this.current[this.x/2 -1][this.x/2 +4] =1;
            this.current[this.x/2 +6][this.x/2 +2] =1;
            this.current[this.x/2 +6][this.x/2 +3] =1;
            this.current[this.x/2 +6][this.x/2 +4] =1;
            this.current[this.x/2 -6][this.x/2 +2] =1;
            this.current[this.x/2 -6][this.x/2 +3] =1;
            this.current[this.x/2 -6][this.x/2 +4] =1;
            this.current[this.x/2 +2][this.x/2 +6] =1;
            this.current[this.x/2 +3][this.x/2 +6] =1;
            this.current[this.x/2 +4][this.x/2 +6] =1;
            this.current[this.x/2 -2][this.x/2 +6] =1;
            this.current[this.x/2 -3][this.x/2 +6] =1;
            this.current[this.x/2 -4][this.x/2 +6] =1;

        }else if(this.pattern.equals("B")){
            this.current[this.x-1][0] =1;
            this.current[this.x-1][this.x-1] =1;
            this.current[0][this.x-1] =1;
            this.current[0][0] =1;
            this.current[1][0] =1;
            this.current[0][this.x-1] =1;

        }

        this.draw();
        this.display();
    }

    public void display(){
        pic.show();
        for(int maxloop=0; maxloop< this.m; maxloop++){
            this.draw();
            this.update();
        }

    }

    public void update() {
        this.previous = deepCopy(this.current);
        for (int col = 0; col < this.x; col++) {
            for (int row = 0; row < this.x; row++) {
                int density = population_density(col, row);
                if(this.previous[col][row] == 1) {
                    if (density < 2) this.current[col][row] = 0; //die becuase of underpopulation
                    else if (density > 3) this.current[col][row] = 0; //die becasue of overpopulation
                    else continue;
                } else {
                    if(density == 3) this.current[col][row] = 1;
                }
            }
        }
    }

    public int population_density(int x, int y) {
        int density = 0;
        for(int a = x-1; a<= x+1; a++) {
            for(int b=y-1; b<= y+1; b++) {
                if(x == a && y == b) {
                    continue;
                }
                int ax = (a + this.x) % this.x;
                int by = (b + this.x) % this.x;
                if (this.previous[ax][by] == 1) density++;
            }
        }
        return density;
    }

    public int[][] deepCopy(int[][] source) {
        int[][] destination = new int[this.x][this.x];
        for(int i=0; i<this.x; i++) {
            for(int j=0; j<this.x; j++) {
                destination[i][j] = source[i][j];
            }
        }
        return destination;
    }

//    public void update(){
//        //main rules to update
//        for(int col=0;col<this.x;col++){
//            for(int row=0;row<this.x;row++){
//                this.previous[col][row] = this.current[col][row];
//            }
//        }
////        System.out.println("top left : " +this.previous[0][0] );
////        System.out.println("top right: " +this.previous[this.x-1][0]);
////        System.out.println("bot left: " +this.previous[0][this.x-1]);
////        System.out.println("bot right: " +this.previous[this.x-1][0]);
//        for(int col=0; col<this.x; col++){
//            for (int row=0; row<this.x; row++){
//                int count=0;
//                if(col==0 && row==0){//top-left
//                    int newcol = ((col+this.x)%this.x);
//                    int newrow = ((row+this.x)%this.x);
//                    //System.out.println("newcol: "+ newcol+" newrow: "+newrow);
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("corner yes " + count);
//                }else if(col== this.x-1 && row==0){//top-right
//                    int newcol = ((col+this.x)%this.x);
//                    int newrow = ((row+1+this.x)%this.x);
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("top right yes " + this.previous[newcol][newrow]);
//
//                }else if(col==0 && row== this.x-1){//bot-left
//                    int newcol = ((col+1+this.x)%this.x);
//                    int newrow = ((row+this.x)%this.x);
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("botleft yes " + this.previous[newcol][newrow]);
//                }else if(col== this.x-1 && row == this.x-1){//bot-right
//                    int newcol = ((col+1+this.x)%this.x);
//                    int newrow = ((row+1+this.x)%this.x);
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("botright yes " + this.previous[newcol][newrow]);
//                }else if(col==0){//left
//                    int newcol = col;
//                    int newrow = ((row+this.x)%this.x);
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("left ONLY yes " + this.previous[newcol][newrow]);
//                }else if(col == this.x-1){//right
//                    int newcol = col;
//                    int newrow= ((row+1+this.x)%this.x);
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("RIGHT ONLY yes " + this.previous[newcol][newrow]);
//                }else if(row ==0){//top
//                    int newcol =((col+this.x)%this.x) ;
//                    int newrow = row;
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("TOP ONLY yes " + this.previous[newcol][newrow]);
//                }else if(row == this.x-1){//bot
//                    int newcol =((col+1+this.x)%this.x);
//                    int newrow =row;
//                    if(this.previous[newcol][newrow]==1)count++;
//                    //System.out.println("BOT ONLY yes " + this.previous[newcol][newrow]);
//                }else{
//                    //for cell that not at the edges
//                    if(this.previous[col+1][row]==1)count++;
//                    if(this.previous[col+1][row-1]==1)count++;
//                    if(this.previous[col+1][row+1]==1)count++;
//                    if(this.previous[col][row-1]==1)count++;
//                    if(this.previous[col][row+1]==1)count++;
//                    if(this.previous[col-1][row]==1)count++;
//                    if(this.previous[col-1][row-1]==1)count++;
//                    if(this.previous[col-1][row+1]==1)count++;
//                }
//                //System.out.println("count: "+count);
//                if(this.previous[col][row]==1){ //live cell
//                    if(count<2){ //underpopulation
//                        this.current[col][row] = 0;
//                        //System.out.println("die underpopulation");
//                    }else if(count>1 && count<4){ // survival
//                        continue;
//                    }else if(count>3){ //overpopulation
//                        //System.out.println("die overpopulation");
//                        this.current[col][row] =0;
//
//                    }
//                }else{//dead cell
//                    if(count==3)this.current[col][row] =1;
//                    //System.out.println("repopulated at : " + col + " , " + row);
//                }
//            }
//        }
//
//    }


    public int countNeighbors(int x, int y ){
        int sum= 0;
        for (int i = -1; i < 2; i++) {
            for (int j = -1; j < 2; j++) {
                if(x==0 || y==0 || x==this.x-1 || y==this.x-1){
                    int col = (x + i + this.x-1) % this.x;
                    int row = (y + j + this.x-1) % this.x;
                    if(this.previous[col][row]==1){
                        System.out.println("previous[col][row] : "+this.previous[col][row]);
                        sum++;
                    }
                }else{
                    for(int k=0; k<this.x;k++){
                        for(int l=0;l<this.x;l++){
                            if(this.previous[k+1][l]==1)sum++;
                            if(this.previous[k+1][l-1]==1)sum++;
                            if(this.previous[k+1][l+1]==1)sum++;
                            if(this.previous[k][l-1]==1)sum++;
                            if(this.previous[k][l+1]==1)sum++;
                            if(this.previous[k-1][l]==1)sum++;
                            if(this.previous[k-1][l-1]==1)sum++;
                            if(this.previous[k-1][l+1]==1)sum++;

                        }

                    }


                }
            }
        }
        System.out.println("sum: "+ sum);
        if(this.previous[x][y]==1){
            sum--;
        }
        //System.out.println("sum: "+ sum);
        return sum;


    }



    public void draw(){
        for(int col=0; col<this.x ; col++){
            for(int row=0; row<this.x ;row++){
                for(int offsetx =0; offsetx< this.magnification; offsetx++) {
                    for (int offsety = 0; offsety < this.magnification; offsety++) {
                        if (this.current[col][row] == 1) {
                            pic.set(col * this.magnification + offsetx, row * this.magnification + offsety, this.black);
                        }else{
                            pic.set(col * this.magnification + offsetx, row * this.magnification + offsety, this.white);
                        }
                    }
                }
            }
        }
        pic.show();
        try {
            Thread.sleep(500L);
        } catch (Exception error) {
        }
    }



    public static void main(String[] var0) {
        Life var1 = new Life(Integer.parseInt(var0[0]), Integer.parseInt(var0[1]), var0[2]);
        var1.display();
    }
}
